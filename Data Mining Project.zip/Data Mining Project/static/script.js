function validateSupport(form) {
    let val = parseFloat(form.min_support.value);
    if (isNaN(val) || val <= 0 || val > 1) {
        alert("Support must be a number between 0 and 1");
        return false;
    }
    return true;
}
