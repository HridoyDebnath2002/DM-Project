from flask import Flask, render_template, request, redirect, url_for, g
import sqlite3
from datetime import datetime
import time
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, fpgrowth
from sklearn.tree import DecisionTreeClassifier
import numpy as np
import pandas as pd

app = Flask(__name__)
DATABASE = 'app.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
        g._database = db
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def get_time_of_day():
    hour = datetime.now().hour
    if 5 <= hour < 12:
        return 'morning'
    elif 12 <= hour < 18:
        return 'afternoon'
    else:
        return 'night'

@app.route('/', methods=['GET'])
def index():
    db = get_db()
    cur = db.execute('SELECT id, name FROM items')
    items = cur.fetchall()
    if len(items) > 5:
        import random
        items = random.sample(items, 5)
    return render_template('index.html', items=items)

@app.route('/purchase', methods=['POST'])
def purchase():
    selected_items = request.form.getlist('items')
    if not selected_items:
        return redirect(url_for('index'))

    db = get_db()
    tod = get_time_of_day()
    cur = db.execute('INSERT INTO transactions (time_of_day) VALUES (?)', (tod,))
    transaction_id = cur.lastrowid
    for item_id in selected_items:
        db.execute('INSERT INTO transaction_items (transaction_id, item_id) VALUES (?, ?)',
                   (transaction_id, item_id))
    db.commit()
    recommended = predict_next_item([int(i) for i in selected_items], tod)

    cur = db.execute('SELECT id, name FROM items')
    items = cur.fetchall()
    if len(items) > 5:
        import random
        items = random.sample(items, 5)
    return render_template('index.html', items=items, recommended=recommended)

@app.route('/frequent', methods=['GET', 'POST'])
def frequent():
    if request.method == 'POST':
        algorithm = request.form['algorithm']
        min_support = float(request.form['min_support'])

        db = get_db()
        cur = db.cursor()
        cur.execute('SELECT id FROM transactions')
        trans_ids = [row[0] for row in cur.fetchall()]
        transactions = []
        for tid in trans_ids:
            cur.execute('''
                SELECT items.name FROM items
                JOIN transaction_items ti ON items.id = ti.item_id
                WHERE ti.transaction_id = ?
            ''', (tid,))
            rows = cur.fetchall()
            items_in_trans = [row['name'] for row in rows]
            transactions.append(items_in_trans)

        te = TransactionEncoder()
        te_ary = te.fit(transactions).transform(transactions)
        df = pd.DataFrame(te_ary, columns=te.columns_)

        start = time.time()
        if algorithm == 'Apriori':
            freq_itemsets = apriori(df, min_support=min_support, use_colnames=True)
        else:
            freq_itemsets = fpgrowth(df, min_support=min_support, use_colnames=True)
        elapsed = time.time() - start

        result_sets = [', '.join(list(x)) for x in freq_itemsets['itemsets']]

        return render_template('frequent.html',
                               itemsets=result_sets,
                               algorithm=algorithm,
                               min_support=min_support,
                               elapsed=elapsed)
    else:
        return render_template('frequent.html')

@app.route('/compare', methods=['GET', 'POST'])
def compare():
    if request.method == 'POST':
        min_support = float(request.form['min_support'])

        db = get_db()
        cur = db.cursor()
        cur.execute('SELECT id FROM transactions')
        trans_ids = [row[0] for row in cur.fetchall()]
        transactions = []
        for tid in trans_ids:
            cur.execute('''
                SELECT items.name FROM items
                JOIN transaction_items ti ON items.id = ti.item_id
                WHERE ti.transaction_id = ?
            ''', (tid,))
            rows = cur.fetchall()
            items_in_trans = [row['name'] for row in rows]
            transactions.append(items_in_trans)

        te = TransactionEncoder()
        te_ary = te.fit(transactions).transform(transactions)
        df = pd.DataFrame(te_ary, columns=te.columns_)

        start_a = time.time()
        apriori_sets = apriori(df, min_support=min_support, use_colnames=True)
        time_a = time.time() - start_a

        start_f = time.time()
        fpgrowth_sets = fpgrowth(df, min_support=min_support, use_colnames=True)
        time_f = time.time() - start_f

        apriori_list = [', '.join(list(x)) for x in apriori_sets['itemsets']]
        fpgrowth_list = [', '.join(list(x)) for x in fpgrowth_sets['itemsets']]

        return render_template('compare.html',
                               apriori_sets=apriori_list,
                               fpgrowth_sets=fpgrowth_list,
                               time_apriori=round(time_a, 4),
                               time_fpgrowth=round(time_f, 4),
                               min_support=min_support)
    else:
        return render_template('compare.html')

def predict_next_item(selected_ids, current_tod):
    db = get_db()
    cur = db.cursor()

    cur.execute('SELECT id, time_of_day FROM transactions')
    rows = cur.fetchall()
    if not rows:
        return None

    cur.execute('SELECT id, name FROM items')
    items = cur.fetchall()
    id_to_name = {}
    all_ids = []
    for row in items:
        id_to_name[row['id']] = row['name']
        all_ids.append(row['id'])
    all_ids.sort()
    item_to_idx = {id: idx for idx, id in enumerate(all_ids)}
    idx_to_id = {idx: id for id, idx in item_to_idx.items()}

    X = []
    Y = []
    for tran_id, tod in rows:
        cur.execute('SELECT item_id FROM transaction_items WHERE transaction_id = ?', (tran_id,))
        tran_items = [r[0] for r in cur.fetchall()]
        if len(tran_items) < 2:
            continue
        for target in tran_items:
            features = [0] * len(all_ids)
            for it in tran_items:
                if it != target:
                    features[item_to_idx[it]] = 1
            if tod == 'morning':
                features.extend([1, 0, 0])
            elif tod == 'afternoon':
                features.extend([0, 1, 0])
            else:
                features.extend([0, 0, 1])
            X.append(features)
            Y.append(item_to_idx[target])

    if not X:
        return None

    clf = DecisionTreeClassifier()
    clf.fit(X, Y) 

    feat = [0] * len(all_ids)
    for it in selected_ids:
        if it in item_to_idx:
            feat[item_to_idx[it]] = 1
    if current_tod == 'morning':
        feat.extend([1, 0, 0])
    elif current_tod == 'afternoon':
        feat.extend([0, 1, 0])
    else:
        feat.extend([0, 0, 1])

    pred_idx = clf.predict([feat])[0]
    predicted_id = idx_to_id[pred_idx]
    return id_to_name.get(predicted_id, None)

if __name__ == '__main__':
    app.run(debug=True)
